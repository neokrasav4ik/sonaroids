#!/usr/bin/env python3
"""Всё в один экран в альбомной ориентации: каждый экран приложения в настоящем браузере (Chromium, playwright) на размерах
iPhone от SE до Pro Max. Проверяю, что ничего не вылезает за экран и нет прокрутки; портрет — только просьба повернуть.
Снимки кладутся в tools/out/layout_*.png. Нужен python-пакет playwright с Chromium; без него стенд пропускается."""
import pathlib, sys
try:
    from playwright.sync_api import sync_playwright
except Exception:
    print('пропущено: нет playwright'); sys.exit(0)
ROOT=pathlib.Path(__file__).resolve().parents[2]; OUT=ROOT/'tools'/'out'; OUT.mkdir(exist_ok=True)
URL='file://'+str(ROOT/'app'/'sonar_lab3.html')
SIZES=[(568,320,'SE-1'),(667,375,'SE'),(750,390,'вырез 844x390'),(844,390,'14'),(932,430,'Pro Max'),(1002,462,'пользователь')]
SETUP={
 'home':"show('home'); el('a2hs').classList.remove('hidden'); el('err').classList.remove('hidden'); el('err').textContent='Не вышло: нет микрофона: нужна вкладка по https'; el('silentP').textContent='В обычном режиме переключатель беззвучного режима глушит зонд. Можно попробовать экспериментальный.'; el('silentT').textContent='Беззвучный режим телефона: не поддерживается (обычный)';",
 'orient':"show('orient');",
 'rec':"show('rec'); el('say').textContent='Ладонь сбоку на 10 см'; el('sub').textContent='У края с микрофоном, ладонью вниз, напротив метки.'; el('clock').textContent='4.2 / 16 с';",
 'recDone':"show('recDone'); var st=el('stats'); ['длительность','разрывов потока','сторона руки','зонд слышен','пик входа','размер'].forEach(function(k){ var r=document.createElement('div'); r.className='kv'; r.innerHTML='<span>'+k+'</span><b>16.0 с</b>'; st.appendChild(r); }); el('share').classList.remove('hidden'); fitScreen();",
 'cal':"show('cal'); CS.busy=false; calText('Готовлюсь','Зонда почти не слышно',NOPROBE); el('calBig').textContent='руки пока не вижу'; el('calDiag').textContent='рука: видна (движение) · эхо +31 дБ над пустой · движение -18 дБ'; el('calLogS').classList.remove('hidden'); fitScreen();",
 'dualIntro':"lastRec='recDual'; show('dualIntro');",
 'recDual':"lastRec='recDual'; show('recSide'); buildHTrack(DUAL_A); el('mkH').style.left=xOf(60)+'px'; el('sdSay').textContent='Закрой пальцем верхний динамик'; el('sdSub').textContent='Узкая щель над экраном, у фронтальной камеры. Три секунды.'; el('sdClock').textContent='10.2 / 45 с';",
 'arkIntro':"lastRec='ark'; show('arkIntro');",
 'arkPlay':"lastRec='ark'; show('arkPlay'); AK.bricks=akBricks(2); AK.ball={x:0.42,y:0.62}; AK.px=0.55; AK.phase='play'; AK.present=true; AK.dist=92; AK.score=120; AK.lives=2; AK.level=2; akDraw(); akText('',''); ",
 'ark_twin':"lastRec='ark'; show('arkPlay'); AK.field='twin'; AK.bricks=akBricks(2); AK.ball={x:0.42,y:0.62}; AK.px=0.3; AK.pd=0.3; AK.phase='play'; AK.present=true; AK.dist=92; AK.score=120; AK.lives=2; AK.level=2; akDraw(); akText('',''); ",
 'ark_funnel':"lastRec='ark'; show('arkPlay'); AK.field='funnel'; AK.bricks=akBricks(2); AK.ball={x:0.42,y:0.62}; AK.px=0.45; AK.pd=0.45; AK.phase='play'; AK.present=true; AK.dist=92; AK.score=120; AK.lives=2; AK.level=2; akDraw(); akText('',''); ",
 'ark_side':"lastRec='ark'; show('arkPlay'); AK.field='side'; AK.bricks=akBricks(2); AK.ball={x:0.42,y:0.62}; AK.px=0.7; AK.pd=0.7; AK.phase='play'; AK.present=true; AK.dist=92; AK.score=120; AK.lives=2; AK.level=2; akDraw(); akText('',''); ",
 'probes':"show('probes');",
 'arcIntro':"lastRec='arc'; arcOpen('slalom');",
 'arc_slalom':"lastRec='arc'; show('arcPlay'); ARC.game='slalom'; ARC.T=null; arcInit(); ARC.flags=[{x:0.9,y:0.3,w:0.28,st:0},{x:1.8,y:0.72,w:0.28,st:0}]; ARC.trail=[0.5,0.48,0.46]; ARC.py=0.46; ARC.phase='play'; ARC.present=true; ARC.dist=92; ARC.t=12; akText('',''); arcDraw(); arcText('','');",
 'arc_bombs':"lastRec='arc'; show('arcPlay'); ARC.game='bombs'; arcInit(); ARC.bombs=[{x:0.9,y:0.3},{x:1.4,y:0.6}]; ARC.by=0.4; ARC.phase='play'; ARC.present=true; ARC.dist=92; ARC.score=24; arcDraw(); arcText('','');",
 'arc_cave':"lastRec='arc'; show('arcPlay'); ARC.game='cave'; arcInit(); ARC.ar=2.16; ARC.t=0; ARC.cols=[]; ARC_STEP.cave(0.001); ARC.phase='play'; ARC.present=true; ARC.dist=92; ARC.py=0.5; arcDraw(); arcText('','');",
 'arc_race':"lastRec='arc'; show('arcPlay'); ARC.game='race'; arcInit(); ARC.ar=2.16; ARC.t=0; ARC_STEP.race(0.001); ARC.cars=[{x:1.1,lane:-0.2,v:0.4,sw:0},{x:1.7,lane:0.25,v:0.4,sw:0}]; ARC.fcans=[{x:1.4,lane:0.1}]; ARC_STEP.race(0.001); ARC.phase='play'; ARC.present=true; ARC.dist=92; ARC.py=0.5; ARC.fuel=70; ARC.v=0.9; arcDraw(); arcText('','');",
 'arcOver':"lastRec='arc'; show('arcPlay'); ARC.game='bombs'; arcInit(); ARC.phase='over'; ARC.score=37; ARC.caught=20; arcDraw(); arcText('Финиш','поймано 20 · очки 37 · волна 2'); arcButtons(true);",
 'pwCheck':"show('pwCheck');",
 'link':"lkLabel(); show('link');",
 'linkBeacon':"show('linkBeacon'); el('lbSay').textContent='Пищу: нечётные тоны'; el('lbNow').textContent='Свой зонд: 42 дБ над шумом | соседа: 27 дБ (на 15 дБ тише) | громкость зонда 0.084';",
 'arkOver':"lastRec='ark'; show('arkPlay'); AK.bricks=akBricks(1); AK.ball={x:0.42,y:0.62}; AK.px=0.55; AK.phase='over'; AK.score=120; AK.lives=0; AK.level=1; akDraw(); akText('Конец','счёт 120 · уровень 1 · лучший 120'); akButtons(true);",
 'menu':"show('game'); el('gPanel').classList.remove('hidden'); el('gLogI').textContent='Записано 150 с партии (последние 150 с). Журнал настройки: 120 с.'; fitScreen();",
}
# 26.09: запись вбок идёт с телефоном вертикально — её экраны проверяю в портрете
PSIZES=[(320,568,'SE-1'),(375,667,'SE'),(390,844,'14'),(430,932,'Pro Max')]
PSETUP={
 'depthIntro':"lastRec='recDepth'; show('depthIntro');",
 'depthAsk':"lastRec='recDepth'; show('recTwo'); el('twAsk').classList.remove('hidden'); el('twSay').textContent='Слышишь писк?'; el('twSub').textContent='Сейчас играет зонд пошире — от 16 кГц. Прислушайся пару секунд.'; twoDraw(null,null);",
 'stIntro':"lastRec='recSt'; show('stIntro');",
 'recSt':"lastRec='recSt'; show('recSt'); el('stSay').textContent='Ладонь справа'; el('stSub').textContent='Так же, с правой стороны. Качай вверх-вниз.'; el('stClock').textContent='11.2 / 30 с'; el('stInfo').innerHTML='каналов от браузера: <b>2</b> · в настройках: 2<br>каналы <b class=\"good\">разные</b>: сходство 0.912, разница уровней -3.1 дБ';",
 'twoIntro':"lastRec='recTwo'; show('twoIntro');",
 'recTwo':"lastRec='recTwo'; show('recTwo'); el('twSay').textContent='По очереди'; el('twSub').textContent='Одна к телефону — другая от него. За метками.'; el('twClock').textContent='21.3 / 63 с'; twoDraw(90,150);",
 'sideIntro':"lastRec='recSide'; show('sideIntro'); sideOri();",
 'recSide':"lastRec='recSide'; show('recSide'); buildHTrack(); el('mkH').style.left=xOf(40)+'px'; el('sdSay').textContent='Замри справа'; el('sdSub').textContent='Напротив метки, на том же расстоянии.'; el('sdClock').textContent='22.4 / 39 с';",
 'rightIntro':"lastRec='recRight'; show('rightIntro'); rightOri();",
 'rightPlay':"lastRec='recRight'; show('rightPlay'); rpText('Помаши ладонью','Справа от нижнего торца: ближе — дальше, от 5 до 15 см. Шесть секунд.'); rpButtons(true); rpDraw();",
 'recRight':"lastRec='recRight'; show('recSide'); el('sdPort').style.display='none'; buildRTrack(); el('mkH').style.left=xOfMM(100)+'px'; el('sdSay').textContent='Ладонь справа, 10 см'; el('sdSub').textContent='Ребром, ладонью к телефону, на одной линии с нижним торцом. Напротив метки.'; el('sdClock').textContent='4.1 / 16 с';",
 'rightPlayFlip':"lastRec='recRight'; document.body.classList.add('flip'); show('rightPlay'); rpText('Переверни телефон','Разъём наверху, от себя. Ладонь — справа от верхнего торца.'); rpButtons(true); rpDraw();",
 'sideDone':"lastRec='recSide'; show('recDone'); var st=el('stats'); ['длительность','разрывов потока','экран','зонд слышен','пик входа','размер'].forEach(function(k){ var r=document.createElement('div'); r.className='kv'; r.innerHTML='<span>'+k+'</span><b>39.0 с</b>'; st.appendChild(r); }); el('share').classList.remove('hidden'); fitScreen();",
}
bad=0
def run(b,sizes,setup):
    global bad
    for (w,h,name) in sizes:
        pg=b.new_page(viewport={'width':w,'height':h})
        pg.goto(URL); pg.wait_for_timeout(200)
        pg.evaluate("()=>{ window.__T={}; }")
        # код приложения живёт внутри замыкания — подключаюсь через тестовый крючок, который собираю тут же из текста страницы
        for scr,js in setup.items():
            pg.goto(URL); pg.wait_for_timeout(150)
            r=pg.evaluate("""(js)=>{ const src=[...document.scripts].map(s=>s.textContent).join('\\n');
                const hook=src.replace("el('gMenu').addEventListener","window.__run=function(c){ eval(c); };\\nel('gMenu').addEventListener");
                document.querySelectorAll('.screen').forEach(s=>s.classList.add('hidden'));
                (0,eval)(hook); window.__run(js);
                const s=[...document.querySelectorAll('.screen')].find(x=>!x.classList.contains('hidden'));
                const t=(!document.getElementById('gPanel').classList.contains('hidden')&&s.id==='game')?document.getElementById('gPanel'):s;
                const out=[]; t.querySelectorAll('*').forEach(e=>{ const r=e.getBoundingClientRect(); if(!r.width||!r.height||getComputedStyle(e).visibility==='hidden') return;
                  if(r.left<-1||r.top<-1||r.right>innerWidth+1||r.bottom>innerHeight+1) out.push((e.id||e.tagName)+' '+Math.round(r.left)+','+Math.round(r.top)+'–'+Math.round(r.right)+','+Math.round(r.bottom)); });
                return {over:t.scrollHeight>t.clientHeight+1||t.scrollWidth>t.clientWidth+1, sh:t.scrollHeight, ch:t.clientHeight, out:out.slice(0,4), fs:getComputedStyle(document.documentElement).fontSize,
                        page:document.documentElement.scrollHeight>innerHeight+1||document.documentElement.scrollWidth>innerWidth+1}; }""",js)
            ok=not r['over'] and not r['out'] and not r['page']
            if not ok: bad+=1
            pg.screenshot(path=str(OUT/f'layout_{scr}_{w}x{h}.png'))
            print(f"{'ok ' if ok else 'НЕ ВЛЕЗАЕТ'} {name:>14} {w}x{h} {scr:8} шрифт {r['fs']:>6} | высота {r['sh']}/{r['ch']}" + ('' if ok else f" | вылезает: {r['out']}"))
        pg.close()
with sync_playwright() as p:
    b=p.chromium.launch()
    run(b,SIZES,SETUP)
    run(b,PSIZES,PSETUP)
    # сторона кнопок: рука справа — кнопки слева; рука слева — зеркально
    for hand in ('right','left'):
        pg=b.new_page(viewport={'width':844,'height':390}); pg.goto(URL); pg.wait_for_timeout(150)
        r=pg.evaluate('''(hand)=>{ document.body.classList.toggle('hand-left',hand==='left');
          const x=id=>{ const e=document.getElementById(id); e.classList.remove('hidden'); return e; };
          const home=x('home'), g=document.getElementById('goGame').getBoundingClientRect(), t=home.querySelector('h1').getBoundingClientRect();
          document.querySelectorAll('.screen').forEach(s=>s.classList.toggle('hidden',s.id!=='game')); ['gStart','gAgain','gSave'].forEach(i=>x(i));
          const st=document.getElementById('gStart').getBoundingClientRect(), mn=document.getElementById('gMenu').getBoundingClientRect();
          return {playLeft:g.left<t.left, startLeft:st.right<innerWidth/2, menuLeft:mn.right<innerWidth/2}; }''',hand)
        want=(hand=='right'); ok=r['playLeft']==want and r['startLeft']==want and r['menuLeft']==want
        if not ok: bad+=1
        pg.screenshot(path=str(OUT/f'layout_game_buttons_{hand}.png'))
        print(f"{'ok ' if ok else 'НЕ ТАК'} рука {'справа' if hand=='right' else 'слева'}: «Играть» {'слева' if r['playLeft'] else 'справа'}, «Старт» {'слева' if r['startLeft'] else 'справа'}, «Меню» {'слева' if r['menuLeft'] else 'справа'}")
        pg.close()
    pg=b.new_page(viewport={'width':390,'height':844}); pg.goto(URL); pg.wait_for_timeout(150)
    vis=pg.evaluate("()=>getComputedStyle(document.getElementById('portrait')).display")
    pg.screenshot(path=str(OUT/'layout_portrait.png')); print('портрет 390x844: просьба повернуть', 'видна' if vis=='flex' else 'НЕ видна')
    if vis!='flex': bad+=1
    b.close()
print('ИТОГ:', 'ok' if bad==0 else f'ПРОВАЛ ({bad})'); sys.exit(1 if bad else 0)
