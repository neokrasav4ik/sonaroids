/* ── FIRST-LAUNCH PICTURES («volume» look, agreed 24 Sep): the table seen from the front-left and above, the phone lying flat,
   the palm hovering by the short edge with the charging port. The palm is slightly smaller than real, the phone 1.6× larger
   than real so its screen is readable: a tiny ship on it follows the palm. Drawn with the port on the right;
   for a left-handed player the whole picture is mirrored (labels are not). ── */
function polyFill(pts,c){ lx.fillStyle=c; if(uiS>1){ lx.beginPath(); pts.forEach(function(q,i){ if(i) lx.lineTo(q[0],q[1]); else lx.moveTo(q[0],q[1]); }); lx.closePath(); lx.fill(); return; } var y0=Math.floor(Math.min.apply(null,pts.map(function(p){return p[1];}))), y1=Math.ceil(Math.max.apply(null,pts.map(function(p){return p[1];})));
  for(var y=y0;y<=y1;y++){ var xs=[], yy=y+0.5; for(var a=0,b=pts.length-1;a<pts.length;b=a++){ var A=pts[a],B=pts[b]; if((A[1]>yy)!==(B[1]>yy)) xs.push(A[0]+(yy-A[1])*(B[0]-A[0])/(B[1]-A[1])); }
    xs.sort(function(p,q){return p-q;}); for(var i=0;i+1<xs.length;i+=2){ var xa=Math.round(xs[i]), xb=Math.round(xs[i+1]); if(xb>xa) lx.fillRect(xa,y,xb-xa,1); } } }
function ease(x){ x=Math.max(0,Math.min(1,x)); return x*x*(3-2*x); }
function waveH(t){ return 0.5+0.5*Math.sin(t*2.4-Math.PI/2); }       // demo waving: 0 — 5 cm, 1 — 15 cm (v0.26: back from 4–12)
/* oblique projection "front-left, from above": the long side of the phone runs along the screen */
function iso(X,Y,Z,o){ return [o[0]+X+0.42*Y, o[1]+0.62*Y-Z]; }
function unIso(sx,sy,o){ var Y=(sy-o[1])/0.62; return [sx-o[0]-0.42*Y, Y]; }
function polyA(pts,c,al){ if(al===undefined||al>=1){ polyFill(pts,c); return; } if(al<=0) return;
  if(uiS>1){ lx.globalAlpha=al; polyFill(pts,c); lx.globalAlpha=1; return; }
  lx.fillStyle=c; var y0=Math.floor(Math.min.apply(null,pts.map(function(p){return p[1];}))), y1=Math.ceil(Math.max.apply(null,pts.map(function(p){return p[1];})));
  for(var y=y0;y<=y1;y++){ var xs=[], yy=y+0.5; for(var a=0,b=pts.length-1;a<pts.length;b=a++){ var A=pts[a],B=pts[b]; if((A[1]>yy)!==(B[1]>yy)) xs.push(A[0]+(yy-A[1])*(B[0]-A[0])/(B[1]-A[1])); }
    xs.sort(function(p,q){return p-q;}); for(var i=0;i+1<xs.length;i+=2) for(var x=Math.round(xs[i]);x<Math.round(xs[i+1]);x++) if(bay(x,y)<al) lx.fillRect(x,y,1,1); } }
function box(x0,x1,y0,y1,z0,z1,o,cT,cX,cY,al){                         // a block: top, front (+Y, towards the player) and left (−X) faces
  polyA([iso(x0,y0,z0,o),iso(x0,y1,z0,o),iso(x0,y1,z1,o),iso(x0,y0,z1,o)],cX,al);
  polyA([iso(x0,y1,z0,o),iso(x1,y1,z0,o),iso(x1,y1,z1,o),iso(x0,y1,z1,o)],cY,al);
  polyA([iso(x0,y0,z1,o),iso(x1,y0,z1,o),iso(x1,y1,z1,o),iso(x0,y1,z1,o)],cT,al); }
function slab(bx,by,d,nb,len,z0,z1,t,ch,o,cF,cT,al){       // a block turned in plan: base (bx,by), length along d, height z0…z1, thickness t along nb (away from the viewer); ch — rounded end
  var ex=bx+d[0]*len, ey=by+d[1]*len, cx=ex-d[0]*ch, cy=ey-d[1]*ch, c2=Math.min(ch,(z1-z0)/2);
  polyA([iso(bx,by,z0,o),iso(cx,cy,z0,o),iso(ex,ey,z0+c2,o),iso(ex,ey,z1-c2,o),iso(cx,cy,z1,o),iso(bx,by,z1,o)],cF,al);
  polyA([iso(bx,by,z1,o),iso(cx,cy,z1,o),iso(cx+nb[0]*t,cy+nb[1]*t,z1,o),iso(bx+nb[0]*t,by+nb[1]*t,z1,o)],cT,al); }
/* v1.05, HD: the drawn palms (src/42_hands.js, made by hands/make_hands.py in this very projection): a picture put at the wrist's
   place, scaled to the scene — it only moves, so the pixel palms' motions stay as they were; until it has loaded, the pixel palm */
var HANDI={};
function handPic(k){ if(typeof HAND_PICS==='undefined') return null; var h=HANDI[k]; if(!h){ h=HANDI[k]=new Image(); h.src=HAND_PICS[k].src; } return h.complete&&h.naturalWidth?h:null; }
function handSprite(k,X,Y,Z,unit,o,al){ var im=handPic(k); if(!im) return false; var d=HAND_PICS[k], s=unit/HAND_PICS.ppcm, p=iso(X,Y,Z,o);
  lx.globalAlpha=Math.max(0,Math.min(1,al)); lx.imageSmoothingEnabled=true; lx.drawImage(im,p[0]-d.ox*s,p[1]-d.oy*s,d.w*s,d.h*s); lx.globalAlpha=1; return true; }
function handIso(Xa,Yb,hz,o,cm,al){                                    // Xa — palm edge by the phone, Yb — wrist, hz — top of the palm
  var HS={t:P.hand[1],h:P.hand[2],x:P.hand[0],y:'#9A7274'}, w=8.5*cm, Xb=Xa+w, Ya=Yb-10*cm, th=2.4*cm, L=[7.4,8.4,7.9,6.3], fw=w/4, i;
  for(i=0;i<4;i++){ var fx0=Xa+i*fw+0.35*cm, fx1=Xa+(i+1)*fw-0.35*cm;
    box(fx0,fx1,Ya-L[i]*cm,Ya,hz-1.9*cm,hz-0.35*cm,o,HS.t,HS.x,HS.y,al);
    var tip=iso((fx0+fx1)/2,Ya-L[i]*cm+0.9*cm,hz-0.35*cm,o); if(al>0.5) R(HS.h,tip[0]-1,tip[1],2,1); }
  box(Xa,Xb,Ya,Yb,hz-th,hz,o,HS.t,HS.x,HS.y,al);
  box(Xa-4.6*cm,Xa+0.2*cm,Ya+4.2*cm,Ya+6.4*cm,hz-2.7*cm,hz-0.9*cm,o,HS.t,HS.x,HS.y,al);          // thumb, towards the phone
  for(i=0;i<4;i++){ var k2=iso(Xa+(i+0.5)*fw,Ya+0.7*cm,hz,o); if(al>0.5) R(HS.x,k2[0]-1,k2[1],2,1); }
  var e0=iso(Xa+0.5*cm,Ya+0.3*cm,hz,o), e1=iso(Xb-0.5*cm,Ya+0.3*cm,hz,o); if(al>0.5) for(var q=0;q<=1;q+=0.05) R(HS.h,e0[0]+(e1[0]-e0[0])*q,e0[1]+(e1[1]-e0[1])*q,1,1);
  box(Xa+0.8*cm,Xb-0.8*cm,Yb,Yb+11*cm,hz-3.2*cm,hz-0.2*cm,o,HS.t,HS.x,HS.y,al);                 // forearm, towards the player,
  box(Xa+0.8*cm,Xb-0.8*cm,Yb+11*cm,Yb+17*cm,hz-3.4*cm,hz-0.4*cm,o,HS.t,HS.x,HS.y,al*0.55);      // fading further on
}
var PSC=1.6;
function portLabel(ph,o,labels){ var y=Math.round(iso(ph.X1,ph.Y1,0,o)[1])+5, x=Math.round(ph.port[0]);          // v0.35: under the phone, the arrow points up at the port
  labels.push({x:x,y:y,t:'↑',c:P.pick,a:'center'}); labels.push({x:x,y:y+10,t:L(ph.cam?'cam':'port'),c:P.pick,a:'center'}); }
/* v1.05, HD (the maintainer: «перерисовать телефоны»): a phone with rounded corners, a metal side all round, a black bezel, the screen's
   own rounded corners, the island at the camera's end and a glass glare — the same box as the pixel one, drawn smooth */
function rrPts(x0,x1,y0,y1,r){ var pts=[], c=[[x1-r,y0+r,-1.5708],[x1-r,y1-r,0],[x0+r,y1-r,1.5708],[x0+r,y0+r,3.1416]];
  c.forEach(function(q){ for(var a=0;a<=6;a++){ var an=q[2]+a/6*1.5708; pts.push([q[0]+Math.cos(an)*r,q[1]+Math.sin(an)*r]); } }); return pts; }
function isoPath(pts,z,o){ lx.beginPath(); pts.forEach(function(p,i){ var q=iso(p[0],p[1],z,o); if(i) lx.lineTo(q[0],q[1]); else lx.moveTo(q[0],q[1]); }); lx.closePath(); }
function phoneIsoHD(o,cm,portOn,cam){
  var X0=-7.5*cm*PSC,X1=7.5*cm*PSC,Y0=-3.6*cm*PSC,Y1=3.6*cm*PSC,Zp=1.0*cm, r=1.9*cm, body=rrPts(X0,X1,Y0,Y1,r), n=Math.max(4,Math.round(Zp*uiS/0.6)), k;
  for(k=0;k<=n;k++){ var q=k/n; lx.fillStyle='rgb('+Math.round(42+q*96)+','+Math.round(39+q*92)+','+Math.round(53+q*104)+')'; isoPath(body,Zp*q*0.98,o); lx.fill(); }   // the side: dark at the bottom, light at the top edge
  lx.fillStyle='#0c0b14'; isoPath(body,Zp,o); lx.fill(); lx.strokeStyle='#5b5670'; lx.lineWidth=0.35; lx.stroke();
  var m=0.55*cm; lx.fillStyle=P.bg; isoPath(rrPts(X0+m,X1-m,Y0+m,Y1-m,r-0.45*cm),Zp,o); lx.fill();
  var PX=cam?X0:X1, sx=PX+(cam?0.28:-0.28)*cm, pa=iso(sx,-0.8*cm,Zp,o), pb=iso(sx,0.8*cm,Zp,o);                                      // the charging port, on the rim at its end
  lx.strokeStyle=!cam&&portOn?P.pick:'#3a3648'; lx.lineWidth=0.5; lx.lineCap='round'; lx.beginPath(); lx.moveTo(pa[0],pa[1]); lx.lineTo(pb[0],pb[1]); lx.stroke();
  return {X0:X0,X1:X1,Y0:Y0,Y1:Y1,Zp:Zp,port:cam?iso(X1-0.25*cm,0,Zp,o):iso(PX,0,Zp,o),cam:!!cam,hd:{m:m,r:r-0.45*cm,camOn:!!(cam&&portOn)}}; }
function phoneIso(o,cm,portOn,cam){                                          // cam: the hand's end is the front-camera end (v0.17)
  if(uiS>1) return phoneIsoHD(o,cm,portOn,cam);
  var X0=-7.5*cm*PSC,X1=7.5*cm*PSC,Y0=-3.6*cm*PSC,Y1=3.6*cm*PSC,Zp=1.0*cm, q;
  box(X0,X1,Y0,Y1,0,Zp,o,P.rock[2],P.rock[1],P.rock[0]);
  polyFill([iso(X0+0.5*cm,Y0+0.45*cm,Zp,o),iso(X1-0.5*cm,Y0+0.45*cm,Zp,o),iso(X1-0.5*cm,Y1-0.45*cm,Zp,o),iso(X0+0.5*cm,Y1-0.45*cm,Zp,o)],P.bg);
  for(var g=0;g<2;g++){ var a0=iso(X0+(2.2+g*1.3)*cm,Y1-0.8*cm,Zp,o), a1=iso(X0+(3.6+g*1.3)*cm,Y0+0.8*cm,Zp,o);
    for(q=0;q<=1;q+=0.06) if(bay(Math.round(a0[0]+(a1[0]-a0[0])*q),Math.round(a0[1]+(a1[1]-a0[1])*q))<0.5) R(P.neb[1],a0[0]+(a1[0]-a0[0])*q,a0[1]+(a1[1]-a0[1])*q,1,1); }
  var PX=cam?X0:X1, pa=iso(PX,-0.9*cm,Zp,o), pb=iso(PX,0.9*cm,Zp,o), port=iso(PX,0,Zp,o); for(q=0;q<=1;q+=0.1) R(!cam&&portOn?P.pick:P.rock[3],pa[0]+(pb[0]-pa[0])*q,pa[1]+(pb[1]-pa[1])*q,1,1);
  var camP=iso(X1-0.25*cm,0,Zp,o); if(cam){ R(portOn?P.pick:P.rock[0],camP[0]-1,camP[1]-1,3,3); R(P.bg,camP[0],camP[1],1,1); }       // the front camera: a dot at the hand's end
  return {X0:X0,X1:X1,Y0:Y0,Y1:Y1,Zp:Zp,port:cam?camP:port,cam:!!cam};
}
/* the tiny game on the drawn phone's screen. It is drawn after the picture is mirrored: a turned-over phone turns its screen too,
   so the ship stays on the player's left and flies right */
/* v0.76 (the maintainer: the drawn phone's game in the chosen skin and graphics): the skin's own world — its sky, rocks, saucer, shots and
   ship, the ship at the palm's height — drawn off-screen (pixels, or the HD pictures) and laid onto the phone's screen in perspective */
var phoneSt={}, phoneC=null, phoneHC=null, phoneAt=-1, PHONE_SHIPK=4;   // v0.84: the ship on the drawn phone ~3× larger (the maintainer: «оочень маленький кораблик — его вообще не видно», his pick «А»)
function phoneWorld(f){ if(mode==='race') return racePhone(f); var sk=SK, k=PHONE_SHIPK, hh=Math.max(LH*0.12,7*k+4), sy=hh+(1-f)*(LH-2*hh), sx=LW*0.12+10*(k-1.4);
  if(phoneAt===clock) return sk.hd?phoneHC:phoneC; phoneAt=clock;                       // two phones in one picture share the frame
  if(sk.hd){ var q=Math.min(hs,1.5); if(!phoneHC||phoneHC.width!==Math.round(LW*q)||phoneHC.height!==Math.round(LH*q)){ phoneHC=document.createElement('canvas'); phoneHC.width=Math.round(LW*q); phoneHC.height=Math.round(LH*q); }
    var keep=hx; hx=phoneHC.getContext('2d'); hx.setTransform(q,0,0,q,0,0); hx.imageSmoothingEnabled=true; noLight=true;
    try{ drawDemo(sk,DT,sx,phoneSt,sy,0.15,k); } finally { hx=keep; noLight=false; } return phoneHC; }
  if(!phoneC||phoneC.width!==LW||phoneC.height!==LH){ phoneC=document.createElement('canvas'); phoneC.width=LW; phoneC.height=LH; }
  var kl=lx; lx=phoneC.getContext('2d'); lx.setTransform(1,0,0,1,0,0); lx.imageSmoothingEnabled=false; noLight=true;
  try{ drawDemo(sk,DT,sx,phoneSt,sy,0.15,k); } finally { lx=kl; noLight=false; } return phoneC; }   // v0.77: the ship 1.4×; v0.84: 4× (PHONE_SHIPK)
/* v1.05: whatever draws the screen, what lies on top of the phone (the holding hand's fingers, HD) comes after it */
function phoneGame(ph,o,cm,f,T,mirror){ phoneGame0(ph,o,cm,f,T,mirror); if(ph.after) ph.after(mirror); }
function phoneGame0(ph,o,cm,f,T,mirror){
  var HD=ph.hd, m=HD?HD.m:0.9*cm, x0=ph.X0+m, x1=ph.X1-m, y0=ph.Y0+m, y1=ph.Y1-m, W0=x1-x0, H0=y1-y0;
  function at(u,v){ if(!mirror) return iso(x0+u*W0,y0+v*H0,ph.Zp,o); var p=iso(x0+(1-u)*W0,y0+v*H0,ph.Zp,o); return [LW-p[0],p[1]]; }
  function uvPath(pts){ lx.beginPath(); pts.forEach(function(q,i){ var p=at(q[0],q[1]); if(i) lx.lineTo(p[0],p[1]); else lx.moveTo(p[0],p[1]); }); lx.closePath(); }
  var scr=null;
  if(HD){ scr=[]; var ru=HD.r/W0, rv=HD.r/H0; [[1-ru,rv,-1.5708],[1-ru,1-rv,0],[ru,1-rv,1.5708],[ru,rv,3.1416]].forEach(function(q){ for(var a=0;a<=6;a++){ var an=q[2]+a/6*1.5708; scr.push([q[0]+Math.cos(an)*ru,q[1]+Math.sin(an)*rv]); } }); }
  if(SK&&typeof drawDemo==='function'){ var wc=phoneWorld(f), a0=at(0,0), a1=at(1,0), a2=at(0,1);
    lx.save(); if(HD){ uvPath(scr); lx.clip(); } lx.transform(a1[0]-a0[0],a1[1]-a0[1],a2[0]-a0[0],a2[1]-a0[1],a0[0],a0[1]); lx.imageSmoothingEnabled=true; lx.imageSmoothingQuality='high'; lx.drawImage(wc,0,0,1,1); lx.restore();
    if(HD){ var iu=ph.cam?0.955:0.045, iw=0.014, ih=0.2;                                                       // the island at the camera's end
      uvPath([[iu-iw,0.5-ih],[iu+iw,0.5-ih],[iu+iw,0.5+ih],[iu-iw,0.5+ih]]); lx.fillStyle=HD.camOn?P.pick:'#000'; lx.fill(); lx.lineJoin='round'; lx.strokeStyle=HD.camOn?P.pick:'#000'; lx.lineWidth=1.2; lx.stroke();
      var g0=at(0,0), g1=at(0.5,1), gr=lx.createLinearGradient(g0[0],g0[1],g1[0],g1[1]); gr.addColorStop(0,'rgba(255,255,255,0.12)'); gr.addColorStop(1,'rgba(255,255,255,0)');
      uvPath(scr); lx.fillStyle=gr; lx.fill(); }
    return; }
  if(uiS>1){ for(var i2=0;i2<14;i2++){ var u2=((i2*0.137+T*0.05*(1+i2%3))%1), v2=(i2*0.311)%1, p2=at(1-u2,v2); lx.fillStyle=i2%3?P.stars[1]:P.stars[2]; lx.beginPath(); lx.arc(p2[0],p2[1],0.45,0,6.2832); lx.fill(); }
    [[0.62,0.3,3],[0.83,0.68,2],[0.45,0.8,2]].forEach(function(r,j){ var u=(((r[0]-T*0.04*(j+1))%1)+1)%1*0.9+0.08, p=at(u,r[1]); lx.fillStyle=P.rock[3]; lx.beginPath(); lx.arc(p[0],p[1],r[2]*0.6,0,6.2832); lx.fill(); lx.fillStyle=P.rock[1]; lx.beginPath(); lx.arc(p[0]+r[2]*0.15,p[1]+r[2]*0.15,r[2]*0.4,0,6.2832); lx.fill(); });
    var sq=at(0.12,0.12+(1-f)*0.76), sx2=sq[0]+(mirror?-1:1)*2, d2=mirror?-1:1; lx.fillStyle=P.ship[2]; lx.beginPath(); lx.moveTo(sx2+d2*8,sq[1]); lx.lineTo(sx2,sq[1]-3.6); lx.lineTo(sx2+d2*1.5,sq[1]); lx.lineTo(sx2,sq[1]+3.6); lx.closePath(); lx.fill();
    lx.fillStyle=P.flame[1]; lx.beginPath(); lx.moveTo(sx2+d2*0.8,sq[1]-1); lx.lineTo(sx2-d2*2.5,sq[1]); lx.lineTo(sx2+d2*0.8,sq[1]+1); lx.fill();
    lx.strokeStyle=P.bullet; lx.lineWidth=0.8; lx.lineCap='round'; for(var b2=0;b2<3;b2++){ var bu2=((T*0.9+b2/3)%1)*0.7+0.22, bq=at(bu2,0.12+(1-f)*0.76); lx.beginPath(); lx.moveTo(bq[0]-1.2,bq[1]); lx.lineTo(bq[0]+1.2,bq[1]); lx.stroke(); } return; }
  for(var i=0;i<14;i++){ var u=((i*0.137+T*0.05*(1+i%3))%1), v=(i*0.311)%1, p=at(1-u,v); R(i%3?P.stars[1]:P.stars[2],p[0],p[1],1,1); }
  [[0.62,0.3,3],[0.83,0.68,2],[0.45,0.8,2]].forEach(function(r,j){ var u=(((r[0]-T*0.04*(j+1))%1)+1)%1*0.9+0.08, p=at(u,r[1]);
    R(P.rock[3],p[0]-1,p[1]-1,r[2],r[2]); R(P.rock[2],p[0],p[1],r[2]-1,r[2]-1); });
  var sp=at(0.12,0.12+(1-f)*0.76); blit(SHIP_MAP,P.ship,Math.round(sp[0])-2,Math.round(sp[1])-5);
  for(var b=0;b<3;b++){ var bu=((T*0.9+b/3)%1)*0.7+0.22, bp=at(bu,0.12+(1-f)*0.76); R(P.bullet,bp[0],bp[1],3,1); }
}
/* the scene. id: 'phone' | 'away' | 'wave'; t — seconds on this screen; f — palm height 0…1 (5…15 cm); away — 0…1 how far the hand has left;
   waves — probe waves on. Returns labels (in picture coordinates) */
var tableC=null;
function scene(id,t,f,away,waves,T,lay){
  var cm=Math.min(LH*0.024,LW*0.0135)*(lay?lay.k:1), o=lay?[LW*lay.ox,LH*lay.oy+23.6*cm]:[LW*0.43,LH*0.16+23.6*LH*0.024], labels=[];      // narrow screens (iPad): scale to the width
  var TX0=-21.1*cm, TX=31.1*cm, TY0=-13.3*cm, TY1=17.3*cm, fl=iso(TX0,TY0,0,o)[0];          // v0.35: the table 10% smaller
  if(lay&&!lay.solo&&fl<LW*0.04) TX0+=LW*0.04-fl;                                     // and, beside the second picture, it stops short of the left edge
  var fr=iso(TX,TY1,0,o)[0]; if(lay&&!lay.solo&&fr>LW*0.47) TX-=fr-LW*0.47;           // …and of the middle, where the second picture starts
  var tkey=LW+'x'+LH+'x'+uiS+(lay?':'+lay.ox+':'+lay.k:'');
  if(!tableC||tableC._k!==tkey){ tableC=document.createElement('canvas'); tableC.width=Math.round(LW*uiS); tableC.height=Math.round(LH*uiS); tableC._k=tkey; var keep=lx; lx=tableC.getContext('2d'); lx.setTransform(uiS,0,0,uiS,0,0);
    polyFill([iso(TX0,TY0,0,o),iso(TX,TY0,0,o),iso(TX,TY1,0,o),iso(TX0,TY1,0,o)],P.neb[1]);
    for(var yy=0;yy<LH;yy+=3) for(var xx=(yy%6?2:0);xx<LW;xx+=4){ var q0=unIso(xx,yy,o); if(q0[0]>TX0&&q0[0]<TX&&q0[1]>TY0&&q0[1]<TY1){ if(uiS>1){ lx.fillStyle=P.neb[2]; lx.beginPath(); lx.arc(xx+0.5,yy+0.5,0.4,0,6.2832); lx.fill(); } else R(P.neb[2],xx,yy,1,1); } }
    var tc=[iso(TX0,TY0,0,o),iso(TX,TY0,0,o),iso(TX,TY1,0,o),iso(TX0,TY1,0,o)];                   // v0.35: a thin edge, so the table never melts into the nebula behind it
    if(uiS>1){ lx.strokeStyle=P.stars[0]; lx.lineWidth=0.7; lx.beginPath(); tc.forEach(function(q,i){ if(i) lx.lineTo(q[0],q[1]); else lx.moveTo(q[0],q[1]); }); lx.closePath(); lx.stroke(); } else
    for(var e=0;e<4;e++){ var e0=tc[e], e1=tc[(e+1)%4], n=Math.ceil(Math.max(Math.abs(e1[0]-e0[0]),Math.abs(e1[1]-e0[1])));
      for(var u=0;u<=n;u++) R(P.stars[0],e0[0]+(e1[0]-e0[0])*u/n,e0[1]+(e1[1]-e0[1])*u/n,1,1); }
    lx=keep; }
  lx.drawImage(tableC,0,0,LW,LH);
  var ph=phoneIso(o,cm,id==='phone'&&Math.floor(T*3)%2===0,typeof camEnd==='function'&&camEnd());
  var HSC=0.85, hw=8.5*cm*HSC, Xa=ph.X1+1.2*cm, Yb=5*cm, al=1, Z5=5*cm, Z15=15*cm;          // v0.26: back to 5–15 cm (4–12 was tried in v0.22–0.25)
  var hz=Z5+(Z15-Z5)*f+2.4*cm*HSC, dy=0;
  if(id==='phone') dy=(1-ease(t/1.8))*28*cm;
  if(away>0){ var q=ease(away); dy=q*30*cm; hz+=q*8*cm; al=1-q; }
  if(al>0.1){ var sc=[Xa+hw/2,Yb-8*cm*HSC+dy], dens=Math.max(0.15,0.8-(hz/cm)*0.035)*al;       // the palm's shadow: paler the higher it is
    var rx=5.2*cm*HSC, ry=11*cm*HSC, c4=[iso(sc[0]-rx,sc[1]-ry,0,o),iso(sc[0]+rx,sc[1]-ry,0,o),iso(sc[0]-rx,sc[1]+ry,0,o),iso(sc[0]+rx,sc[1]+ry,0,o)];
    var bx0=Math.max(0,Math.floor(Math.min(c4[0][0],c4[1][0],c4[2][0],c4[3][0]))), bx1=Math.min(LW,Math.ceil(Math.max(c4[0][0],c4[1][0],c4[2][0],c4[3][0])));
    var by0=Math.max(0,Math.floor(Math.min(c4[0][1],c4[1][1],c4[2][1],c4[3][1]))), by1=Math.min(LH,Math.ceil(Math.max(c4[0][1],c4[1][1],c4[2][1],c4[3][1])));
    lx.fillStyle=P.neb[0];
    if(uiS>1){ lx.globalAlpha=Math.min(1,dens*1.1); lx.beginPath(); for(var a3=0;a3<6.3;a3+=0.2){ var q3=iso(sc[0]+Math.cos(a3)*rx,sc[1]+Math.sin(a3)*ry,0,o); if(a3) lx.lineTo(q3[0],q3[1]); else lx.moveTo(q3[0],q3[1]); } lx.fill(); lx.globalAlpha=1; } else
    for(var y2=by0;y2<by1;y2++) for(var x2=bx0;x2<bx1;x2++){ var q1=unIso(x2,y2,o), ex=(q1[0]-sc[0])/rx, ey=(q1[1]-sc[1])/ry; if(ex*ex+ey*ey<1&&bay(x2,y2)<dens) lx.fillRect(x2,y2,1,1); } }
  // v0.69: the waves from both ends of the phone, alike (the maintainer: the palm is heard at either end)
  if(waves&&uiS>1){ lx.strokeStyle=P.bullet; lx.lineWidth=0.8; lx.lineCap='round'; for(var i4=0;i4<3;i4++){ var r4=((T*6+i4*4.5)%13.5)*cm+1*cm; lx.globalAlpha=Math.max(0,1-r4/(15*cm));
    [1,-1].forEach(function(sd){ lx.beginPath(); for(var a4=-1.4;a4<=1.41;a4+=0.07){ var q4=iso((sd>0?ph.X1:ph.X0)+sd*Math.cos(a4)*r4,Math.sin(a4)*r4,0,o); if(a4>-1.4) lx.lineTo(q4[0],q4[1]); else lx.moveTo(q4[0],q4[1]); } lx.stroke(); }); } lx.globalAlpha=1; }
  else if(waves) for(var i=0;i<3;i++){ var rr=((T*6+i*4.5)%13.5)*cm+1*cm;
    for(var a=-1.4;a<=1.4;a+=0.05){ var pp=iso(ph.X1+Math.cos(a)*rr,Math.sin(a)*rr,0,o), pq=iso(ph.X0-Math.cos(a)*rr,Math.sin(a)*rr,0,o); R(P.bullet,pp[0],pp[1],1,1); R(P.bullet,pq[0],pq[1],1,1); } }
  if(id==='wave'){ var rX=Xa+hw+8.5*cm, rY=Yb-12*cm, b0=iso(rX,rY,0,o), b5=iso(rX,rY,Z5,o), b15=iso(rX,rY,Z15,o);         // a 5–15 cm ruler
    dots(b0[0],b0[1],b15[1],P.soft); R(P.soft,b5[0]-3,b5[1],7,1); R(P.soft,b15[0]-3,b15[1],7,1);
    labels.push({x:b15[0]+6,y:b15[1]-3,t:'10 '+L('cm'),c:P.soft});   /* v0.31: the numbers say 5–10 (plays better, the maintainer); the ruler and tuning are unchanged */ labels.push({x:b5[0]+6,y:b5[1]-3,t:'5 '+L('cm'),c:P.soft}); }
  if(al>0.5&&id!=='phone'&&uiS===1){ var d0=iso(Xa+hw,Yb,0,o), d1=iso(Xa+hw,Yb,hz-2.4*cm*HSC,o); dots(d0[0],d1[1],d0[1],P.soft); }   // v1.05: not in HD (the maintainer: «артефакт шкалы убрать»)
  if(al>0&&!(uiS>1&&handSprite('table',Xa+hw/2,Yb+dy,hz-1.2*cm*HSC,cm*HSC*1.25,o,al))) handIso(Xa,Yb+dy,hz,o,cm*HSC,al);
  labels.screen={ph:ph,o:o,cm:cm,f:f,T:T};
  if(id==='phone') portLabel(ph,o,labels);
  return labels;
}
/* sound picture: a speaker and the volume scale with 3–7 lit. On the maintainer's iPhone (24 Sep) the probe follows the media volume —
   the one the side buttons change while the game plays; the silent switch does not mute it */
var SPEAKER=['...11....','..111..1.','11111...1','11111.1.1','11111...1','..111..1.','...11....'];
function soundVolume(t){ var k=Math.max(3,Math.round(LH/55)), cy=Math.round(LH*0.5), x2=Math.round(LW/2-13*k);
  if(uiS>1){ lx.fillStyle=P.text; lx.beginPath(); lx.moveTo(x2,cy-2*k); lx.lineTo(x2+2*k,cy-2*k); lx.lineTo(x2+5*k,cy-4.5*k); lx.lineTo(x2+5*k,cy+3.5*k); lx.lineTo(x2+2*k,cy+1*k); lx.lineTo(x2,cy+1*k); lx.closePath(); lx.fill();
    lx.strokeStyle=P.text; lx.lineWidth=0.8*k; lx.lineCap='round'; [2.2,4].forEach(function(rr){ lx.beginPath(); lx.arc(x2+5.5*k,cy-0.5*k,rr*k,-0.8,0.8); lx.stroke(); }); } else bigBlit(SPEAKER,P.text,x2,cy-4*k,k);
  var ios=isIOS(), top=ios?6:3, lvl=Math.min(top,Math.floor((t%3)*top)+1), bx=x2+11*k;   // v0.86: an iPhone's band is 40–60% (bars 4–6)   // v0.45: the band marks 20–30% (bars 2–3 of 10), was 30–70%
  for(var j=0;j<10;j++){ var h=Math.round((3+j*1.1)*k*0.6), xb=bx+j*Math.round(k*1.6), yb=cy+3*k-h;
    if(ios?(j>=3&&j<=5):(j>=1&&j<=2)) R(P.band,xb-1,yb-1,Math.round(k)+2,h+2); R(j<lvl?P.text:P.line,xb,yb,Math.round(k),h); } }
/* draw a picture function into the side canvas and copy it onto the screen, mirrored when the port is on the left */
function picture(fn,mirror){
  var keep=lx, pcx=pc.getContext('2d'); pcx.clearRect(0,0,LW,LH); lx=pcx; var labels;
  try{ labels=fn()||[]; } finally { lx=keep; }
  if(mirror){ lx.save(); lx.translate(LW,0); lx.scale(-1,1); lx.drawImage(pc,0,0,LW,LH); lx.restore(); } else lx.drawImage(pc,0,0,LW,LH);
  (labels.screens||(labels.screen?[labels.screen]:[])).forEach(function(sc){ phoneGame(sc.ph,sc.o,sc.cm,sc.f,sc.T,mirror); });
  labels.forEach(function(l){ var s=l.t, x=l.x, a=l.a||'left';
    if(mirror){ x=LW-x; a=a==='left'?'right':a==='right'?'left':a; if(l.arrow) s=s.replace('← ','')+' →'; }
    text(s,x,l.y,l.c,a); });
}

/* v0.35: the second way to play — the phone held in the air by the other hand, the palm edge-on at the port end, 5–10 cm away
   (26 Sep, the maintainer: as precise as on the table). The same "volume" look, no table. f — distance 0…1 (5…10 cm) */
function sceneHand(id,t,f,away,waves,T,lay){
  var cm=Math.min(LH*0.024,LW*0.0135)*lay.k, o=[LW*lay.ox,LH*lay.oy+23.6*cm], labels=[];
  var HS={t:P.hand[1],h:P.hand[2],x:P.hand[0],y:'#9A7274'}, X0=-7.5*cm*PSC, Y0=-3.6*cm*PSC, Y1=3.6*cm*PSC, Zp=1.0*cm;
  // the holding hand (v0.35, the maintainer: the phone lies in the palm, the thumb under it, the other fingers over the far long edge)
  var HDH=uiS>1&&!!handPic('hold')&&!!handPic('end'), gx=-2.4*cm, ph, j;   // v1.05: HDH — the drawn hands; v0.69: the phone held in the middle (the maintainer: a hand at the end covers its microphone)
  if(!HDH) box(gx-1.8*cm,gx+6.6*cm,Y0+0.3*cm,Y1-0.2*cm,-2.4*cm,-0.05*cm,o,HS.t,HS.x,HS.y);                      // the palm under the phone, wide
  if(!HDH) for(j=0;j<4;j++) box(gx+0.1*cm+j*1.7*cm,gx+1.6*cm+j*1.7*cm,Y0-1.1*cm,Y0,-1.6*cm,Zp+0.9*cm,o,HS.t,HS.x,HS.y);   // fingers up the far side…
  if(!HDH) box(gx-2.0*cm,gx+5.4*cm,Y1-1.4*cm,Y1+9*cm,-7.4*cm,-2.0*cm,o,HS.t,HS.x,HS.y);                          // forearm towards the player and down
  if(!HDH) box(gx-2.0*cm,gx+5.4*cm,Y1+9*cm,Y1+14*cm,-9.8*cm,-4.4*cm,o,HS.t,HS.x,HS.y,0.55);
  ph=phoneIso(o,cm,id==='phone'&&Math.floor(T*3)%2===0,typeof camEnd==='function'&&camEnd());
  if(!HDH) for(j=0;j<4;j++) box(gx+0.1*cm+j*1.7*cm,gx+1.6*cm+j*1.7*cm,Y0-0.2*cm,Y0+(2.6-(j===3?0.7:0)-(j===0?0.3:0))*cm,Zp,Zp+0.9*cm,o,HS.t,HS.x,HS.y);   // …curled onto the top
  if(!HDH) box(gx+1.0*cm,gx+5.4*cm,Y1-0.6*cm,Y1+1.2*cm,-1.9*cm,-0.2*cm,o,HS.t,HS.x,HS.y);                       // the thumb under the near edge
  var al=1, gap=(5+10*f)*cm, dy=0;                                                             // v0.39: 5–15 cm from the end (the maintainer: on the OnePlus it plays better a bit farther)
  if(id==='phone') dy=(1-ease(t/1.8))*28*cm;
  if(away>0){ var q=ease(away); dy=q*30*cm; gap+=q*6*cm; al=1-q; }
  var Za=-4.2*cm, Zb=4.4*cm, Kx=ph.X1+gap+2.8*cm, Ky=-2.0*cm+dy, D=[0,-1], NB=[1,0], PL=8.5*cm, Wx=Kx-D[0]*PL, Wy=Ky-D[1]*PL;   // a straight hand along the phone's end (v0.35, the maintainer): knuckles K, wrist W, fingers along D, back of the hand along NB
  if(waves) for(var i=0;i<3;i++){ var rr=((T*6+i*4.5)%13.5)*cm+1*cm;
    for(var a=-1.2;a<=1.2;a+=0.06){ var pp=iso(ph.X1+Math.cos(a)*rr,0,Zp/2+Math.sin(a)*rr*0.8,o), pq=iso(ph.X0-Math.cos(a)*rr,0,Zp/2+Math.sin(a)*rr*0.8,o); if(Math.cos(a)*rr<gap) R(P.bullet,pp[0],pp[1],1,1); R(P.bullet,pq[0],pq[1],1,1); } }
  if(HDH){ ph.after=function(mr){ lx.save(); if(mr){ lx.translate(LW,0); lx.scale(-1,1); } handSprite('hold',gx+2.4*cm,Y1-0.5*cm,-2.2*cm,cm,o,1); lx.restore(); };   // on top of the phone's screen: its hidden parts are left out of the picture
    if(al>0) handSprite('end',Kx+0.95*cm,Ky+PL,(Za+Zb)/2,cm*1.05,o,al); }
  else if(al>0){ var fz=[2.9,0.6,-1.7,-3.9], fh=[1.5,1.5,1.45,1.3], L2=[7.6,8.6,8.0,6.2], k;            // index … little finger, top to bottom
    for(k=3;k>=0;k--) slab(Kx-D[0]*0.6*cm,Ky-D[1]*0.6*cm,D,NB,(L2[k]+0.6)*cm,fz[k]*cm,(fz[k]+fh[k])*cm,0.9*cm,0.5*cm,o,HS.t,HS.h,al);
    if(al>0.5) for(k=0;k<3;k++){ var g0=iso(Kx,Ky,fz[k]*cm-0.4*cm,o), g1=iso(Kx+D[0]*(Math.min(L2[k],L2[k+1])-0.3)*cm,Ky+D[1]*(Math.min(L2[k],L2[k+1])-0.3)*cm,fz[k]*cm-0.4*cm,o);   // the lines between the fingers
      for(var u=0;u<=1;u+=0.02) R(HS.y,g0[0]+(g1[0]-g0[0])*u,g0[1]+(g1[1]-g0[1])*u,1,2); }
    slab(Wx,Wy,D,NB,PL,Za,Zb,1.9*cm,0,o,HS.t,HS.h,al);                                                    // the palm
    if(al>0.5) for(k=0;k<3;k++){ var c0=iso(Kx-D[0]*1.4*cm,Ky-D[1]*1.4*cm,fz[k]*cm-0.25*cm,o), c1=iso(Kx,Ky,fz[k]*cm-0.25*cm,o);
      for(u=0;u<=1;u+=0.1) R(HS.y,c0[0]+(c1[0]-c0[0])*u,c0[1]+(c1[1]-c0[1])*u,1,1); }
    var tx=Wx+D[0]*2.0*cm-NB[0]*0.9*cm, ty=Wy+D[1]*2.0*cm-NB[1]*0.9*cm;                                     // the thumb on top, along the index finger, a little towards the phone
    slab(tx,ty,D,NB,7.2*cm,Zb-0.2*cm,Zb+1.7*cm,1.5*cm,0.7*cm,o,HS.x,HS.h,al);
    if(al>0.5){ var h0=iso(tx+D[0]*1.2*cm,ty+D[1]*1.2*cm,Zb-0.3*cm,o), h1=iso(tx+D[0]*6.6*cm,ty+D[1]*6.6*cm,Zb-0.3*cm,o); for(u=0;u<=1;u+=0.03) R(HS.y,h0[0]+(h1[0]-h0[0])*u,h0[1]+(h1[1]-h0[1])*u,1,1); }
    box(Wx-1.0*cm,Wx+2.4*cm,Wy-0.8*cm,Wy+9*cm,Za+1.6*cm,Za+6.4*cm,o,HS.t,HS.x,HS.y,al);                 // forearm straight towards the player, along the phone's end
    box(Wx-1.0*cm,Wx+2.4*cm,Wy+9*cm,Wy+14*cm,Za+1.4*cm,Za+6.2*cm,o,HS.t,HS.x,HS.y,al*0.55);
  }
  if(id==='wave'){ var rz=Zb+10.5*cm, r0=iso(ph.X1,0,rz,o), r5=iso(ph.X1+5*cm,0,rz,o), r10=iso(ph.X1+15*cm,0,rz,o);   // a 0–15 cm ruler from the port, above the picture (0–10 before v0.39)
    for(var x=r0[0];x<=r10[0];x+=2) R(P.soft,x,r0[1],1,1); R(P.soft,r0[0],r0[1]-2,1,5); R(P.soft,r5[0],r5[1]-2,1,5); R(P.soft,r10[0],r10[1]-2,1,5);
    labels.push({x:r5[0]-2,y:r5[1]-11,t:'5',c:P.soft}); labels.push({x:r10[0]-2,y:r10[1]-11,t:'15 '+L('cm'),c:P.soft}); }
  labels.screen={ph:ph,o:o,cm:cm,f:f,T:T};
  if(id==='phone') portLabel(ph,o,labels);
  return labels;
}
/* both ways on one screen: on the table (left) and in the hand (right), «OR» between */
var SPLIT_T={ox:0.25,oy:0.2,k:0.62}, SPLIT_H={ox:0.70,oy:0.16,k:0.62};
function sceneBoth(id,t,f,away,waves,T){
  var a=scene(id,t,f,away,waves,T,SPLIT_T), b=sceneHand(id,t,f,away,waves,T,SPLIT_H), out=a.concat(b);
  out.screens=[a.screen,b.screen]; out.push({x:Math.round(LW*0.515),y:Math.round(LH*0.55),t:L('or'),c:P.soft,a:'center'}); return out;
}
