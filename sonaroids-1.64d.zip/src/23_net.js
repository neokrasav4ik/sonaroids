/* ── LEADERBOARD CLIENT (v0.25): talks to server/server.js at api.sonaroids.app.
   A game is sent as its seed, field width, start height and the palm height of every core step — rounded to 1/4000,
   and the game itself steps with exactly those rounded numbers, so the server's replay lands on the same score.
   The player is a random secret kept on the device (sonaroids_pid); the nickname is asked once, at the first place in a table.
   No network (or a local file) — nothing is sent; a game that could not be sent is kept (the last 3) and tried again later. ── */
var Board=(function(){
  var API=(typeof window!=='undefined'&&window.SONAROIDS_API)||'https://api.sonaroids.app', Q=4000, NONE=65535;
  var cur=null, last=null, cache={}, pending=null, devFn=null, model='';
  /* v0.29: with every game goes a short note on the phone (see devInfo in 49_main.js; the server keeps only known keys).
     Android's model name comes from Chrome's userAgentData, asked once; iPhone gives none. */
  try{ var uad=typeof navigator!=='undefined'&&navigator.userAgentData; if(uad&&uad.getHighEntropyValues&&uad.platform==='Android')
    uad.getHighEntropyValues(['model']).then(function(h){ model=String(h.model||'').replace(/[^A-Za-z0-9 _.()+-]/g,'').slice(0,32); },function(){}); }catch(e){}
  function dev(){ var d=null; try{ d=devFn?devFn():null; }catch(e){} if(d&&model) d.model=model; return d; }
  function ls(k,v){ try{ if(v===undefined) return localStorage.getItem(k); if(v===null) localStorage.removeItem(k); else localStorage.setItem(k,v); }catch(e){} return null; }
  function on(){ return !!(typeof window!=='undefined'&&(window.SONAROIDS_API||location.protocol==='https:'))&&typeof fetch==='function'; }
  function pid(){ var p=ls('sonaroids_pid'); if(p&&/^[0-9a-f]{32}$/.test(p)) return p;
    var a=new Uint8Array(16); crypto.getRandomValues(a); p=''; for(var i=0;i<16;i++) p+=(a[i]<16?'0':'')+a[i].toString(16); ls('sonaroids_pid',p); return p; }
  function nick(){ return ls('sonaroids_nick'); }
  /* the palm height the game steps with: rounded so that the server can repeat it exactly */
  function q(h){ return h===null||h===undefined?null:Math.round(h*Q)/Q; }
  function start(seed,FW,y0,x){ if(x&&x.test){ cur=null; last={state:'test'}; return; }   /* v1.35: a game by test rules (the shots' tilt) is not for the tables */
    cur={core:x&&x.core||Core.TAG,seed:seed,FW:FW,y0:y0,q:[],game:x&&x.game||null,steer:x&&x.steer||null}; last=null;   // v1.01: x — SonaRace: {game:'race', core, steer}
    if(cur.game==='pong'){ cur.ar=x.ar; cur.sens=x.sens; cur.span=x.span; cur.marks=[]; } }   /* v1.62b: SonaLob — {game:'pong', core, ar, sens, span} */
  /* v1.62b: SonaLob's palm is the share of the travel the rules take, already rounded by the game to 4 digits (k/10000), below 0 and above
     1 too: it goes as k+2000 (k kept within −2000…22000 — past that the racket is at its stop at every sensitivity, the game the same) */
  function step(h){ if(!cur) return; if(cur.game==='pong'){ cur.q.push(h===null||h===undefined?NONE:Math.max(-2000,Math.min(22000,Math.round(h*10000)))+2000); return; } cur.q.push(h===null?NONE:Math.round(h*Q)); }
  /* v1.62b: SonaLob's marks, as its log keeps them: [step, 'resume'] — the first step after a pause; [step, 'sens', 0…3] */
  function mark(m){ if(cur&&cur.marks) cur.marks.push(m); }
  function b64(u8){ var s='', CH=0x8000; for(var i=0;i<u8.length;i+=CH) s+=String.fromCharCode.apply(null,u8.subarray(i,i+CH)); return btoa(s); }
  function pack(qs){ var u8=new Uint8Array(qs.length*2); for(var i=0;i<qs.length;i++){ u8[2*i]=qs[i]&255; u8[2*i+1]=qs[i]>>8; }
    if(typeof CompressionStream!=='function') return Promise.resolve({enc:'raw',hands:b64(u8)});
    try{ var cs=new CompressionStream('deflate-raw'), w=cs.writable.getWriter(); w.write(u8); w.close();
      return new Response(cs.readable).arrayBuffer().then(function(ab){ return {enc:'deflate',hands:b64(new Uint8Array(ab))}; },function(){ return {enc:'raw',hands:b64(u8)}; }); }
    catch(e){ return Promise.resolve({enc:'raw',hands:b64(u8)}); } }
  function keep(body){ var l=[]; try{ l=JSON.parse(ls('sonaroids_unsent')||'[]'); }catch(e){} l.push(body); ls('sonaroids_unsent',JSON.stringify(l.slice(-3))); }
  function post(path,body){ return fetch(API+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}).then(function(r){ return r.json().then(function(j){ j.http=r.status; return j; });   /* v0.33: was j.code — it overwrote the transfer code */ }); }
  /* a game is over (or dropped): send it. last — what the game-over screen shows: sending | done | offline | old | error */
  function finish(score){ var c=cur; cur=null; if(!c||!on()||!(score>0)||!c.q.length) return; last={state:'sending',score:score}; var d=dev();
    pack(c.q).then(function(p){ var body={pid:pid(),core:c.core,seed:c.seed,FW:c.FW,y0:c.y0,enc:p.enc,hands:p.hands,score:score,dev:d}; if(c.game){ body.game=c.game; body.steer=c.steer; }
      if(c.game==='pong'){ delete body.FW; delete body.y0; delete body.steer; body.ar=c.ar; body.sens=c.sens; body.span=c.span; body.marks=c.marks; }
      return post('/v1/game',body).then(function(j){ cache={};
        if(j.ok) last={state:'done',score:j.score,ranks:j.ranks,here:j.here||null,listed:j.listed,named:j.named||!!nick()};
        else if(j.error==='core') last={state:'old'}; else last={state:'error',why:j.error}; },
      function(){ keep(body); last={state:'offline'}; }); }); }
  /* v0.29: how getting ready went, from every player — also those who never get to play (no microphone, the probe not heard, the palm
     never caught). Sent once and forgotten: result caught | nocatch | quiet | noprobe | error | nomic | noaudio | lost; t — seconds on the wave step,
     flips — how many times the game suggested the other end of the phone. */
  function setup(result,x){ if(!on()) return; x=x||{}; var b={pid:pid(),result:result,dev:dev()};
    if(typeof x.t==='number') b.t=Math.round(x.t*10)/10; if(typeof x.flips==='number') b.flips=x.flips;
    try{ post('/v1/setup',b).catch(function(){}); }catch(e){} }
  /* games that could not be sent before: try again (at launch and after a game) */
  function flush(){ if(!on()||pending) return; var l=[]; try{ l=JSON.parse(ls('sonaroids_unsent')||'[]'); }catch(e){} if(!l.length) return;
    ls('sonaroids_unsent',null); pending=Promise.all(l.map(function(b){ return post('/v1/game',b).catch(function(){ keep(b); }); })).then(function(){ pending=null; cache={}; }); }
  function setNick(n){ return post('/v1/nick',{pid:pid(),nick:n}).then(function(j){ if(j.ok){ ls('sonaroids_nick',j.nick); cache={}; if(last&&last.state==='done') last.named=true; } return j; }); }
  /* v0.32: the transfer code — Safari, the home-screen app and another phone are different players (the key lives in the browser's storage).
     link: this device asks for a code; claim: this device enters it, takes over that player's key and name, and its own games are joined in */
  function link(){ return post('/v1/link',{pid:pid()}); }
  function claim(code){ return post('/v1/claim',{pid:pid(),code:code}).then(function(j){ if(j.ok&&/^[0-9a-f]{32}$/.test(j.pid)){
      var l=[]; try{ l=JSON.parse(ls('sonaroids_unsent')||'[]'); }catch(e){} l.forEach(function(b){ b.pid=j.pid; }); if(l.length) ls('sonaroids_unsent',JSON.stringify(l));
      ls('sonaroids_pid',j.pid); ls('sonaroids_nick',j.nick||null); cache={}; } return j; }); }
  /* a table: cached for 30 s; state loading | ok | offline */
  function top(period,game,people){ var gq=game==='race'||game==='pong'?'&game='+game:'', key=period+gq+(people?'|people':''), c=cache[key];   /* v1.62b: and SonaLob's */   /* v1.31: people — without the server's bots */ if(c&&(c.state==='loading'||Date.now()-c.at<30000)) return c;   // v1.01: game 'race' — SonaRace's tables
    c=cache[key]={state:'loading',at:Date.now()}; if(!on()){ c.state='offline'; return c; }
    fetch(API+'/v1/top?period='+period+'&limit=10'+gq+(people?'&bots=0':''),{headers:{'X-Player':pid()}}).then(function(r){ return r.json(); })
      .then(function(j){ c.state='ok'; c.entries=j.entries||[]; c.me=j.me||null; c.at=Date.now(); },function(){ c.state='offline'; c.at=Date.now(); });
    return c; }
  return {setup:setup,link:link,claim:claim,devInfo:function(f){ devFn=f; },q:q,start:start,step:step,mark:mark,finish:finish,flush:flush,setNick:setNick,top:top,nick:nick,on:on,
    last:function(){ return last; }, _set:function(p,c){ cache[p]=c; }, _last:function(l){ last=l; }};
})();
