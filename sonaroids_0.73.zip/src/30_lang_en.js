/* ── UI strings, English. All caps: the game's pixel font is drawn in capitals on screen. ── */
var STR={};
STR.en={
  title:'SONAROIDS', android:'ON ANDROID IT DOES NOT WORK ON EVERY PHONE', source:'SOURCE CODE', version:'VERSION', play:'PLAY', recal:'RECALIBRATE', howto:'HOW TO PLAY', or:'OR', covered:"DON'T COVER THE SPEAKER AND MIC", fullscr:'FOR FULL SCREEN MODE, ADD THE SITE TO YOUR HOME SCREEN', lang:'РУССКИЙ', sfx_row:'SOUNDS', sfx_off:'SOUNDS: OFF',
  next:'NEXT', volume:'SET THE VOLUME TO 20–30%', volume_s:'WITH THE VOLUME BUTTONS', volume_direct:'THE VOLUME IS TOO LOW — TURN IT UP TO 20–30%', volume_loud:'THE VOLUME IS TOO HIGH — TURN IT DOWN TO 20–30%',
  phone_t:'PUT THE PHONE DOWN OR HOLD IT', phone_s_cam:'SCREEN UP, FRONT CAMERA TOWARDS YOUR PLAYING HAND', cam:'CAMERA', phone_s:'SCREEN UP, CHARGING PORT TOWARDS YOUR PLAYING HAND', port:'PORT',
  mic_t:'THE GAME HEARS YOUR HAND', mic_s:'IT LISTENS TO THE ECHO OF AN INAUDIBLE SOUND', allow:'ALLOW THE MICROPHONE',
  here:'WAVE HERE', here_cam:'WAVE HERE, AT THE CAMERA', here_port:'WAVE HERE, AT THE PORT', flip_hint:'OTHER HAND? TURN THE PHONE AROUND',
  app_upd:'CHECK FOR UPDATES', get_apk:'GET THE ANDROID APP',
  probe_t:'CHOOSE THE PROBE', probe_s:'WITH THIS SOUND THE PHONE HEARS YOUR HAND', probe_wide:'WIDE', probe_wide1:'CLEANER CONTROL', probe_wide2:'CHILDREN AND PETS MAY HEAR IT',
  probe_norm:'NORMAL', probe_norm1:'SILENT', probe_norm2:'SLIGHTLY ROUGHER CONTROL',
  away_t:'TAKE YOUR HAND AWAY', away_s:'LISTENING TO THE EMPTY ROOM', away_ok:'THE ROOM IS QUIET',
  aud_fx:'PHONE PROCESSING:', aud_src:'SOURCE', aud_usage:'PROBE AS', aud_end:'PROBE FROM', turn_t:'TURN THE PHONE ROUND', hub_s:'GAMES YOU PLAY WITH YOUR PALM', soon:'SOON', all_games:'← ALL GAMES', skin:'SKIN', gfx:'GRAPHICS', gfx_pixel:'PIXELS', skin_space:'SPACE', skin_fairy:'FAIRY TALE', turn_s:'BY 180° IF YOU PLAY', turn_s2:'WITH YOUR RIGHT HAND', turn_h:'ROUND LIKE A WHEEL — DON\'T FLIP IT FACE DOWN', lefty:'I PLAY LEFT-HANDED', aud_vol:'VOLUME', aud_keep:'LEAVE AS IS', aud_cam:'CAMERA END', aud_port:'PORT END', aud_media:'MEDIA', aud_game:'GAME', aud_autotest:'AUTO PICK', aud_notyet:'NOT DONE YET', aud_retest:'TEST AGAIN', aud_lab:'LAB', aud_nextgame:'WITH THE NEXT GAME', aud_link:'SOUND', aud_t:'APP SOUND', aud_s:'WHERE THE GAME TAKES THE MICROPHONE FROM AND WHERE THE PROBE PLAYS', aud_mode:'SOUND', aud_browser:'BROWSER', aud_app:'APP', aud_mic:'MICROPHONE', aud_out:'SPEAKER', aud_auto:'AUTO', aud_speaker:'SPEAKER', aud_earpiece:'EARPIECE', aud_bottom:'BOTTOM', aud_top:'TOP', aud_back:'BACK', aud_now:'NOW:', aud_active:'RECORDING:', aud_idle:'THE MICROPHONE OPENS WITH THE GAME', aud_browser_now:'NOW THE SOUND GOES THROUGH THE BROWSER: ANDROID PICKS THE MICROPHONE', aud_nopos:'THE PHONE DOES NOT TELL WHERE ITS MICROPHONES ARE',
  wave_t:'WAVE YOUR PALM', wave_s:'5–10 CM ABOVE THE TABLE OR 5–15 CM FROM THE PHONE\'S END', wave_ok:'GOT YOUR RANGE', other_t:'WAVE ON THE OTHER SIDE', other_s:'THE PHONE DOES NOT HEAR THE PALM ON THIS SIDE', try_s:'THE SHIP FOLLOWS YOUR PALM — TRY THE TOP AND THE BOTTOM', cm:'CM',
  ring_wait:'GET READY', ring_listen:'LISTENING', ring_catch:'CATCHING THE RANGE', ring_ok:'DONE',
  start:'START', over:'GAME OVER', best:'BEST', again:'AGAIN', menu:'MENU', logs:'LOGS',
  lost_t:'NO PROBE SOUND', lost_s:'SOUND WENT TO ANOTHER DEVICE. UNPLUG HEADPHONES OR BLUETOOTH', retry:'TRY AGAIN',
  nomic_t:'NO MICROPHONE', nomic_s:'ALLOW IT IN THE BROWSER SETTINGS AND TRY AGAIN', noaudio_s:'THIS BROWSER CANNOT PLAY THE GAME. TRY SAFARI OR CHROME',
  rotate:'TURN THE PHONE SIDEWAYS', rotate_s:'THE SCREEN WON\'T TURN? SWITCH OFF THE ROTATION LOCK: ON IPHONE IN CONTROL CENTRE, ON ANDROID IN QUICK SETTINGS (AUTO-ROTATE)', paused:'PAUSE', resume:'GO ON', quit:'END THE GAME', scores:'HIGH SCORES', p_day:'TODAY', p_week:'THIS WEEK', p_all:'ALL TIME', loading:'LOADING…', offline:'NO CONNECTION TO THE TABLE', empty:'EMPTY SO FAR', you:'YOU',
  name:'NAME', name_set:'SET YOUR NAME', nick_t:'YOU MADE THE TABLE!', nick_t2:'YOUR NAME IN THE TABLE', nick_s:'UP TO 16 CHARACTERS: LATIN LETTERS, DIGITS AND _', done:'DONE', later:'LATER',
  nick_bad:'THAT NAME IS NOT ALLOWED', nick_net:'NO CONNECTION — TRY LATER', sending:'SENDING TO THE TABLE…', sent_off:'OFFLINE — WILL SEND LATER', old:'UPDATE THE GAME TO GET INTO THE TABLE',
  here_day:'THIS GAME: #{n} TODAY', here_week:'THIS GAME: #{n} THIS WEEK', here_all:'THIS GAME: #{n} ALL TIME',
  pb_day:'YOUR BEST TODAY: #{n}', pb_week:'YOUR BEST THIS WEEK: #{n}', pb_all:'YOUR BEST: #{n}',
  link:'TRANSFER', link_t:'TRANSFER YOUR SCORES', link_s:'SAFARI, THE HOME SCREEN AND ANOTHER PHONE ARE DIFFERENT PLAYERS TO THE GAME. A CODE JOINS THEM INTO ONE: THE NAME AND THE SCORES BECOME SHARED',
  link_show:'SHOW A CODE', link_in:'ENTER A CODE', link_code_t:'TRANSFER CODE', link_code_s:'ON THE OTHER DEVICE: HIGH SCORES → TRANSFER → ENTER A CODE. THE CODE WORKS FOR 10 MINUTES',
  link_in_t:'ENTER THE CODE', link_in_s:'THE OTHER DEVICE SHOWS IT: HIGH SCORES → TRANSFER → SHOW A CODE', link_bad:'WRONG OR EXPIRED CODE',
  link_ok_t:'DONE', link_ok_s:'NOW IT IS ONE PLAYER{nick}. THE SCORES ARE JOINED',
  place_day:'#{n} TODAY', place_week:'#{n} THIS WEEK', place_all:'#{n} ALL TIME', restart:'START OVER', restart_s:'KEEP THE CALIBRATION OR RECALIBRATE?', rs_go:'PLAY NOW', back:'BACK', exit:'EXIT TO MENU', menu_a:'MENU'
};
